#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <math.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <linux/limits.h>
#include "statuscodes.h"

// Should be defined in a config file or as argv params or similar
#define PORT 80
#define NUMWORKERS 6
#define GROUPID 1002
#define USERID 1001
#define HTTP_ROOT "/home/lutoma/public_html/"
#define INDEXFILE "index.html"

#define VERSION "0.1.0"
#define ERROR_TEMPLATE "<!DOCTYPE html><html><head><title>Error %d: %s</title><style type=\"text/css\">body {text-align: center;}</style></head><body><h1>Error %d: %s</h1><hr />xhttpd/0.1.0</body></html>"
#define BUFFER_START_SIZE 512

#define error(desc, ret) do { printf("Error: %s (%s)\n",  desc, strerror(errno)); return ret; } while(0);

int socket_fd = -1;

int http_write(int socket, char* string)
{
	int length = strlen(string);
	int numbytes = write(socket, string, length);

	if(numbytes != length)
		error("Could not write response", false);
}

int http_write_status(int socket, int code)
{
	char* description = statuscodes[code] ? statuscodes[code] : "Unknown error";
	printf("Writing status line: %d %s\n", code, description);
	char* line = (char*)malloc(sizeof(char) * (strlen(description) + 15));

	if(!line)
		error("Could not allocate", 1);

	sprintf(line, "HTTP/1.1 %d %s\r\n", code, description);
	http_write(socket, line);
	free(line);
	return 0;
}

int http_write_content(int socket, char* content, int content_length)
{
	int int_length = floor(log10(abs(content_length))) + 1;
	char* header = (char*)malloc(sizeof(char) * (content_length + 19));
	sprintf(header, "Content-Length: %d\r\n", content_length);

	http_write(socket, header);
	http_write(socket, "\r\n");
	http_write(socket, content);

	free(header);
}

void http_error(int socket, int errcode)
{
	printf("HTTP error %d\n", errcode);
	http_write_status(socket, errcode);

	// Write common headers
	http_write(socket, "Connection: close\r\n");
	http_write(socket, "Server: xhttpd\r\n");

	// Write response
	char* description = statuscodes[errcode] ? statuscodes[errcode] : "Unknown error";
	int length = (strlen(description) - 1) * 2 + strlen(ERROR_TEMPLATE) + 6;
	char* line = (char*)malloc(sizeof(char) * length);
	sprintf(line, ERROR_TEMPLATE, errcode, description, errcode, description);
	http_write_content(socket, line, strlen(line));
	free(line);
}

void handle_request(int socket, char* request, int request_length)
{
	printf("\nNew request:\n");

	char method[5];
	memset(method, 0, 5);
	memcpy(method, request, 4);

	for(int i = 0; i < 4; i++)
		if(method[i] == ' ')
			method[i] = 0;

	char path[PATH_MAX];
	memset(path, 0, PATH_MAX);

	int i = strlen(method) + 1;
	for(int j = 0; j < PATH_MAX; i++, j++)
	{
		if(request[i] == ' ' || request[i] < 0)
			break;
		
		path[j] = request[i];
	}

	printf("%s %s\n", method, path);

	if(strcmp(method, "GET"))
	{
		printf("Invalid method %s.\n", method);
		http_error(socket, 501);
		return;
	}

	// Is this a directory?
	if(path[strlen(path) - 1] == '/')
	{
		if(strlen(path) + strlen(INDEXFILE) > PATH_MAX)
			http_error(socket, 414);
		
		strcat(path, INDEXFILE);
	}

	FILE* input = fopen(path, "rb");
	if(input == NULL)
	{
		switch(errno)
		{
			case ENOENT:
				http_error(socket, 404); return;
			case EACCES:
			case EISDIR:
				http_error(socket, 403); return;
			default:
				http_error(socket, 500);
				error("Could not open source file", );
		}
	}

	char buffer[1000000];
	int len = fread(buffer, 1, 1000000, input);
	if(len < 1)
	{
		switch(errno)
		{
			case EISDIR:
				http_error(socket, 403); return;
			default:
				http_error(socket, 500);
				error("Couldn't read input file", );
		}
	}

	// Write answer code
	http_write_status(socket, 200);

	// Write common headers
	http_write(socket, "Connection: close\r\n");
	http_write(socket, "Server: xhttpd\r\n");
	//http_write(socket, "Content-Type: image/jpeg\r\n");

	http_write_content(socket, buffer, len);
	fclose(input);
}

void stop()
{
	printf("Closing connection...\n");
	close(socket_fd);
}

void handle_signal(int signal)
{
	printf("Received sigterm, cleaning up.\n");
	exit(EXIT_SUCCESS);
}

int main(int argc, char* argv[])
{
	socket_fd = socket(AF_INET, SOCK_STREAM, 0);

	if(socket_fd < 0)
		error("Error opening socket", 1);

	// Register stop function that closes the socket
	atexit(stop);

	// Register signal handler
	signal(SIGINT, handle_signal);
	signal(SIGHUP, handle_signal);
	signal(SIGTERM, handle_signal);

	/* Set SO_REUSEADDR to true. Normally, the kernel blocks a TCP port for one
	 * minute after it was closed so that any ingoing packets to the 'old'
	 * server don't confuse the new one. We don't need that.
	 */
	int one = 1;
	if(setsockopt(socket_fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one)) == -1)
		error("Could not setsockopt", EXIT_FAILURE);

	struct sockaddr_in listen_addr;
	memset(&listen_addr, 0, sizeof(struct sockaddr_in));

	listen_addr.sin_family = AF_INET;
	listen_addr.sin_addr.s_addr = INADDR_ANY;
	listen_addr.sin_port = htons(PORT);

	if(bind(socket_fd, (struct sockaddr*)&listen_addr, sizeof(listen_addr)) < 0)
		error("Could not bind", 1);

	// Chroot in the webserver directory
	if(chdir(HTTP_ROOT) != 0)
		error("Could not change to root directory", EXIT_FAILURE);
	if(chroot(HTTP_ROOT) != 0)
		error("Could not chroot", EXIT_FAILURE);

	// Drop root privileges (if any)
	if (getuid() == 0) {
		if (setgid(GROUPID) != 0)
			error("setgid: Unable to drop group privileges", 1);
		if (setuid(USERID) != 0)
			error("setuid: Unable to drop user privileges", 1);
	}

	// Fork worker child processes
	//for(int i = 1; i < NUMWORKERS; i++)
	//	if(fork() == 0) break;

	while(true)
	{
		listen(socket_fd, 5);

		struct sockaddr_in client_addr;
		int client_len = sizeof(client_addr);
		int client_socket_fd = accept(socket_fd, (struct sockaddr*)&client_addr, &client_len);

		if(client_socket_fd < 0)
			error("Error accepting client socket", 1);
		
		int buffer_size = BUFFER_START_SIZE;
		char* request = (char*)malloc(sizeof(char) * buffer_size);
		memset(request, 0, sizeof(char) * buffer_size);

		int line_length = 0;
		int request_length = 0;
		int iteration = 0;

		do {
			if(buffer_size < BUFFER_START_SIZE)
			{
				buffer_size = BUFFER_START_SIZE * pow(2, iteration);

				request = realloc(request, sizeof(char) * buffer_size);
				if(!request)
					error("Reallocating request buffer failed", EXIT_FAILURE);
			}

			line_length = read(client_socket_fd, &request[request_length], buffer_size);
			if(line_length < 0)
				error("Could not read()", EXIT_FAILURE);

			request_length += line_length;
			buffer_size -= line_length;

			if(request_length > 3 && !strcmp(&request[request_length - 3], "\n\r\n"))
				break;

			iteration++;
		} while(line_length > 0);

		if(request_length > 0)
			handle_request(client_socket_fd, request, request_length);

		free(request);
		close(client_socket_fd);
	}

	exit(EXIT_SUCCESS);
}
